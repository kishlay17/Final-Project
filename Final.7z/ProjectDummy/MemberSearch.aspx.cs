﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class MemberSearch : System.Web.UI.Page {
    DataAccessLayer dalObject = new DataAccessLayer();
    DataTable dataTableObject;
    string Member_Id = String.Empty;

    protected void OnPaging(object sender, DetailsViewPageEventArgs e) {
        memberSearchResults.PageIndex = e.NewPageIndex;
        memberSearchResults.DataBind();
        Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
        Session["memberId"] = Member_Id;
    }

    protected void Page_Load(object sender, EventArgs e) {
        if (Session["Admin_Id"] == null) {
            Response.Redirect("login.aspx");
        }

        dataTableObject = dalObject.FunDataTable("select * from members_profile order by cast(substring(mem_id, 2, len(mem_id) - 1) as int)");

        if (dataTableObject.Rows.Count > 0) {
            memberSearchResults.Visible = true;
            memberSearchResults.AutoGenerateRows = true;
            memberSearchResults.DataSource = dataTableObject;
            memberSearchResults.DataBind();

            if (!IsPostBack) {
                Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
                Session["memberId"] = Member_Id;
            }

            message.Visible = false;
            updatemember.Visible = true;
        }
        else {
            memberSearchResults.Visible = false;
            message.Visible = true;
            message.Text = "No Record Found...";
            updatemember.Visible = false;
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e) {
        dataTableObject = dalObject.FunDataTable("select * from members_profile where Mem_Id = '" + memeberidtextbox.Text.ToString() + "'");

        if (dataTableObject.Rows.Count > 0) {
            memberSearchResults.Visible = true;
            memberSearchResults.AutoGenerateRows = true;
            memberSearchResults.DataSource = dataTableObject;
            memberSearchResults.DataBind();
            //if (!IsPostBack) {
                Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
                Session["memberId"] = Member_Id;
            //}
            message.Visible = false;
            updatemember.Visible = true;
        }
        else {
            memberSearchResults.Visible = false;
            message.Visible = true;
            message.Text = "No Record Found...";
            updatemember.Visible = false;
        }
    }

    protected void updatemember_Click(object sender, EventArgs e) {
        Response.Redirect("MemberProfileUpdate.aspx");
    }
}