﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class login : System.Web.UI.Page {
    string Admin_First_Name = String.Empty;
    string Admin_Id = String.Empty;

    protected void Page_Load(object sender, EventArgs e) {

    }

    protected void LoginControl_Authenticate(object sender, AuthenticateEventArgs e) {
        string username = LoginControl.UserName;
        string password = LoginControl.Password;
        
        if (UserLogin(username, password)) {
            Session["Admin_First_Name"] = Admin_First_Name;
            Session["Admin_Id"] = Admin_Id;
            e.Authenticated = true;
        }
        else {
            e.Authenticated = false;
        }
    }

    private bool UserLogin(string username, string password) {
        using (DataAccessLayer ob = new DataAccessLayer()) {
            using (SqlDataReader dr = ob.FunExecuteReader("select * from admin_profile where Admin_Id = @username and Admin_Client_Id = @password", username, password)) {

                if (dr.HasRows) {
                    dr.Read();
                    Admin_Id = dr[0].ToString();
                    Admin_First_Name = dr[1].ToString();
                    return true;
                }
            }
        }
        
        return false;
    }
}