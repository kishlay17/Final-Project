﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Reflection;

public partial class DummyRegistration : System.Web.UI.Page {
    DataAccessLayer ob = new DataAccessLayer();
    DataTable dt;

    protected void Page_Load(object sender, EventArgs e) {
        dt = ob.FunDataTable("select * from admin_profile");

        if (dt.Rows.Count > 0) {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else {
            Response.Write("Record not Found");
        }

        if (PreviousPage != null) {
            if (PreviousPageViewState != null) {
                TextBox1.Text = PreviousPageViewState["memberId"].ToString();
            }
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e) {

    }

    protected void Button1_Click(object sender, EventArgs e) {
        dt = ob.FunDataTable("select * from members_profile");

        if (dt.Rows.Count > 0) {
            DetailsView1.DataSource = dt;
            DetailsView1.DataBind();
        }
        else {
            Response.Write("Record not Found");
        }
    }

    private StateBag PreviousPageViewState {
        get {
            StateBag returnValue = null;

            if (PreviousPage != null) {
                Object objPreviousPage = (Object)PreviousPage;
                MethodInfo objMethod = objPreviousPage.GetType().GetMethod("ReturnViewState");
                return (StateBag)objMethod.Invoke(objPreviousPage, null);
            }
            return returnValue;
        }
    }
}