﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ClaimProcessing : System.Web.UI.Page {
    #region variable declaration
    DataAccessLayer dalObject = new DataAccessLayer();
    DataTable dataTableObject, insuranceObject,claimObject;
    string Member_Id = String.Empty;
    #endregion   
    #region Function for Page Load
    protected void Page_Load(object sender, EventArgs e) {
        if (Session["Admin_Id"] == null) {
            Response.Redirect("login.aspx");
        }

        adminidtextbox.Text = Session["Admin_Id"].ToString();
        BindMemberDetails();
    }
    #endregion
    #region Function for ValidateRequestMemberId
    public bool ValidateRequestMemberId()
    {
        object NoofApperance = dalObject.FunExecuteScalar("select count(Claim_Request_Number) from claim_details c where claim_request_number='" + Session["Claim_Id"].ToString() + "'");
        if (Convert.ToInt32(NoofApperance) > 0)
            return true;
        else
            return false;
    }
    #endregion
    #region Function for BindMemberDetails
    public void BindMemberDetails() {
        if (Session["memberId"] != null) {
            if (ValidateRequestMemberId()) {
                /*dataTableObject = dalObject.FunDataTable("select * from members_profile where mem_id='" + memberidtextbox.Text + "'");
                insuranceObject = dalObject.FunDataTable("select i.* from insurance_type i inner join Members_Profile m on m.ins_type_id = i.type_id where m.mem_id = '" + memberidtextbox.Text + "'");*/
                claimObject = dalObject.FunDataTable("select * from claim_details c inner join Members_Profile m on c.Member_Id = m.Mem_Id inner join insurance_type i on i.Type_Id = m.Ins_Type_Id where claim_request_number = '" + Session["Claim_Id"].ToString() + "'");
                
                if (claimObject.Rows.Count > 0) {
                    memberidtextbox.Text = claimObject.Rows[0][1].ToString();
                    firstNameTextBox.Text = claimObject.Rows[0][8].ToString();
                    lastNameTextBox.Text = claimObject.Rows[0][9].ToString();
                    insuranceTextBox.Text = claimObject.Rows[0][20].ToString();
                    insuredAmtTextBox.Text = claimObject.Rows[0][21].ToString();
                    maxClaimtextbox.Text = claimObject.Rows[0][22].ToString();
                    ReqDateCalender.Text = claimObject.Rows[0][2].ToString().Split(' ')[0];
                    reasonTextBox.Text = claimObject.Rows[0][4].ToString();
                    claimAmountTextbox.Text = claimObject.Rows[0][5].ToString();
                }
            }
            /*else {
                Response.Write("<script>alert('Member does not have any Claim');</script>");
                memberidtextbox.Text = "";
                firstNameTextBox.Text = "";
                lastNameTextBox.Text = "";
                insuranceTextBox.Text = "";
                insuredAmtTextBox.Text = "";
                maxClaimtextbox.Text = "";
                ReqDateCalender.Text = "";
                reasonTextBox.Text = "";
                claimAmountTextbox.Text = "";
            }*/
        }
        else {
            Response.Redirect("ClaimProcessing.aspx");
        }
    }
    #endregion
    /*#region Submit Button
    protected void submitButton_Click(object sender, ImageClickEventArgs e) {
        if (memberidtextbox.Text != "") {
            Session["memberId"] = memberidtextbox.Text;
            BindMemberDetails();
        }
        else {
            Response.Write("<script>alert('Please Enter MemberId')</script>");
        }
    }
    #endregion
    #region Cancel Button
    protected void cancelButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ClaimProcessing.aspx");
    }
    #endregion*/
    #region Approve Button
    protected void approveButton_Click(object sender, EventArgs e)
    {
        dalObject.FunExecuteNonQuery("update claim_details set Claim_Status='" + "Approved" + "' where claim_request_number = '" + Session["Claim_Id"] + "'");
        messageLabel.Text = "Claim Approved...";
    }
    #endregion
    #region Reject Button
    protected void rejectButton_Click(object sender, EventArgs e)
    {
        dalObject.FunExecuteNonQuery("update claim_details set Claim_Status='" + "Rejected" + "' where claim_request_number = '" + Session["Claim_Id"] + "'");
        messageLabel.Text = "Claim Rejected...";
    }
    #endregion    
}