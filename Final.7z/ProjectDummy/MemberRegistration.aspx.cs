﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class MemberRegistration : System.Web.UI.Page {
    DataAccessLayer ob = new DataAccessLayer();
    BusinessLogicLayer bll = new BusinessLogicLayer();
    int nomineeCount = 0;
    DataTable dt;
    DataTable dataTableObject;
    bool emailValidate = true;
    static string MemberId = String.Empty;

    public void reset() {
        foreach(Control x in RegistrationPanel.Controls) {
            if (x is TextBox && !(x.ID.ToString().Equals("adminidtextbox") || x.ID.ToString().Equals("memberidtextbox"))) {
                ((TextBox)x).Text = "";
            }               
        }

        foreach (Control x in nominee1.Controls) {
            if (x is TextBox) {
                ((TextBox)x).Text = "";
            }
        }

        foreach (Control x in nominee2.Controls) {
            if (x is TextBox) {
                ((TextBox)x).Text = "";
            }
        }

        foreach (Control x in nominee3.Controls) {
            if (x is TextBox) {
                ((TextBox)x).Text = "";
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e) {
        if (Session["Admin_Id"] == null) {
            Response.Redirect("login.aspx");
        }

        if (!IsPostBack) {
            dt = new DataTable();
            adminidtextbox.Text = Session["Admin_Id"].ToString();
            memberidtextbox.Text = bll.MemberIdGeneration();
            MemberId = memberidtextbox.Text;
            dt = ob.FunDataTable("select * from insurance_type");
            insurancecombobox.DataSource = dt;
            insurancecombobox.DataTextField = "type_name";
            insurancecombobox.DataValueField = "type_id";
            insurancecombobox.DataBind();
            insuredtextbox.Text = dt.Rows[0][2].ToString();
            maxinsurancetextbox.Text = dt.Rows[0][3].ToString();
            nominee1.Visible = true;
        }
    }

    private bool ValidateEmail(string emailInput) {
        SqlDataReader dr = ob.FunExecuteReader("select Mem_Email_Id from members_profile where Mem_Email_Id = @username and Mem_Id <> @password", emailInput, MemberId);

        if (dr.HasRows) {
            return false;
        }

        return true;
    }

    protected void emailTextBox_TextChanged1(object sender, EventArgs e) {
        if (ValidateEmail(emailTextBox.Text)) {
            emailValidate = true;
        }
        else {
            emailValidate = false;
            Response.Write("<script>alert('Email already exist!')</script>");
        }
    }

    protected void nomineecombobox_SelectedIndexChanged(object sender, EventArgs e) {
        if (nomineecombobox.Text.Equals("1")) {
            nomineeCount = 1;
            nominee1.Visible = true;
            nominee2.Visible = false;
            nominee3.Visible = false;

        }
        else if (nomineecombobox.Text.Equals("2")) {
            nomineeCount = 2;
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = false;
        }
        else if (nomineecombobox.Text.Equals("3")) {
            nomineeCount = 3;
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = true;
        }
    }

    protected void addmemberButton_Click(object sender, EventArgs e) {
        int rowsAffected = ob.FunMemberInsertion("exec usp_meminsert @mid,@fn,@ln,@dob,@gen,@cit,@add,@con,@email,@nomi,@aid,@iid",
            memberidtextbox.Text, firstNameTextBox.Text, lastNameTextBox.Text, dateOfBirthCalender.Text,(Male.Checked)?"M":"F","Indian",addressTextArea.Text,phoneTextBox.Text,
            emailTextBox.Text, Convert.ToString(nomineeCount), adminidtextbox.Text, insurancecombobox.SelectedValue);

        if (rowsAffected > 0)
            Response.Write("<script>alert('Inserted!')</script>");

        switch (nomineecombobox.Text) {
            case "1":
                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox1.Text,
                                            nomineelastnametextbox1.Text,
                                            dateofBirthCalender1.Text,
                                            relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                break;
            case "2":
                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox1.Text,
                                            nomineelastnametextbox1.Text,
                                            dateofBirthCalender1.Text,
                                            relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox2.Text,
                                            nomineelastnametextbox2.Text,
                                            dateofBirthCalender2.Text,
                                            relationTextBox2.Text, memberidtextbox.Text, nomineemale2.Checked ? "M" : "F");
                break;
            case "3":
                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox1.Text,
                                            nomineelastnametextbox1.Text,
                                            dateofBirthCalender1.Text,
                                            relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");

                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox2.Text,
                                            nomineelastnametextbox2.Text,
                                            dateofBirthCalender2.Text,
                                            relationTextBox2.Text, memberidtextbox.Text, nomineemale2.Checked ? "M" : "F");

                ob.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", bll.NomineeIdGeneration(memberidtextbox.Text),
                                            nomineefirstnametextbox3.Text,
                                            nomineelastnametextbox3.Text,
                                            dateofBirthCalender3.Text,
                                            relationTextBox3.Text, memberidtextbox.Text, nomineemale3.Checked ? "M" : "F");
                break;
        }

        Response.Redirect("MemberSearch.aspx");
    }

    protected void insurancecombobox_SelectedIndexChanged(object sender, EventArgs e) {
        string st = insurancecombobox.SelectedValue;
        dataTableObject = ob.FunDataTable("select * from insurance_type where type_id = @memberId",st);
        insuredtextbox.Text = dataTableObject.Rows[0][2].ToString();
        maxinsurancetextbox.Text = dataTableObject.Rows[0][3].ToString();
    }

    protected void cancelButton_Click(object sender, EventArgs e) {
        reset();
    }
}