﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class A_Master : System.Web.UI.MasterPage {
    protected void Page_Load(object sender, EventArgs e) {
        if (Session["Admin_First_Name"] != null) {
            adminName.Text = Session["Admin_First_Name"].ToString();
        }
        else {
            Response.Redirect("login.aspx");
        }
    }

    protected void Logout_Click(object sender, ImageClickEventArgs e) {
        using (DataAccessLayer dalObject = new DataAccessLayer()) {
            dalObject.FunExecuteNonQuery("delete from nominee_table where Nominee_First_Name = ''");
        }

        Session.Abandon();
        Response.Redirect("login.aspx");
    }
}
