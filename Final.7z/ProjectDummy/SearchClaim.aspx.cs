﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;

public partial class SearchClaim : System.Web.UI.Page
{
    #region variable declaration
    DataAccessLayer dalObject = new DataAccessLayer();
    DataTable dataTableObject;
    string Member_Id = String.Empty;
    #endregion

    #region OnPagingFunction
    protected void OnPaging(object sender, DetailsViewPageEventArgs e)
    {
        claimSearchResults.PageIndex = e.NewPageIndex;
        BindMemberDetails();
    }
    #endregion
    #region BindData
    protected void BindData() {
        if (dataTableObject.Rows.Count > 0) {
            viewMore.Visible = true;
            claimSearchResults.Visible = true;
            claimSearchResults.AutoGenerateRows = true;
            claimSearchResults.DataSource = dataTableObject;
            claimSearchResults.DataBind();
            Member_Id = claimSearchResults.Rows[1].Cells[1].Text;

            Session["Claim_Id"] = claimSearchResults.Rows[0].Cells[1].Text;
            Session["memberId"] = Member_Id;
            message.Visible = false;
        }
        else
        {
            viewMore.Visible = false;
            claimSearchResults.Visible = false;
            message.Visible = true;
            message.Text = "No Record Found...";
        }

        Session["memberId"] = Member_Id;
    }
    #endregion
    #region BindMemberDetails
    protected void BindMemberDetails()
    {
        //Member ID Search
        if (searchComboBox.SelectedValue == "0")
        {

            dataTableObject = dalObject.FunDataTable("select c.* from claim_details c inner join Members_Profile m on c.Member_Id = m.Mem_Id where m.Mem_Id = '" + searchtextbox.Text + "'");
            BindData();
        }

            //Member FirstName Search
        else if (searchComboBox.SelectedValue == "1")
        {

            dataTableObject = dalObject.FunDataTable("select c.* from claim_details c inner join Members_Profile m on c.Member_Id = m.Mem_Id where m.Mem_First_Name = '" + searchtextbox.Text + "'");
            BindData();
        }

            //RequestFromDate Search
        else if (searchComboBox.SelectedValue == "2")
        {
            dataTableObject = dalObject.FunDataTable("select c.* from claim_details c inner join Members_Profile m on c.Member_Id = m.Mem_Id where c.Request_Date = '" + searchtextbox.Text + "'");
            if (ValidateRequestToDate()) {
                BindData();
            }
            else
            {
                Response.Write("<script>alert('Request Date is greater than todays date')</script>");
            }
        }
        else if (searchComboBox.SelectedValue == "3")
        {
            dataTableObject = dalObject.FunDataTable("select c.* from claim_details c inner join Members_Profile m on c.Member_Id = m.Mem_Id where c.Process_Date = '" + searchtextbox.Text + "'");
            BindData();
        }
    }
    #endregion
    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] == null) {
            Response.Redirect("login.aspx");
        }
        adminidtextbox.Text = Session["Admin_Id"].ToString();
        viewMore.Visible = false;
    }
    #endregion
    #region SearchButtonClick
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (IsPostBack)
        {
            BindMemberDetails();
        }
    }
    #endregion
    #region ValidateRequestToDate
    protected bool ValidateRequestToDate()
    {
        DateTime today;
        DateTime.TryParseExact(searchtextbox.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out today);
        DateTime dt = Convert.ToDateTime(searchtextbox.Text);
        double ts = (DateTime.Now-dt).TotalDays;

        if(ts>0)
            return true;
        else 
            return false;
    }
    #endregion
    #region CancelButtonClick
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("SearchClaim.aspx");
    }
    #endregion
    #region ComboBox_Selection
    protected void searchComboBox_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (searchComboBox.SelectedValue == "0")
        {
            messageLabel.Text = "Member ID";
            searchtextbox.TextMode = TextBoxMode.SingleLine;
        }
        if (searchComboBox.SelectedValue == "1")
        {
            messageLabel.Text = "First Name";
            searchtextbox.TextMode = TextBoxMode.SingleLine;
        }
        if (searchComboBox.SelectedValue == "2")
        {
            messageLabel.Text = "Request From Date";
            searchtextbox.TextMode = TextBoxMode.Date;
        }
        if (searchComboBox.SelectedValue == "3")
        {
            messageLabel.Text = "Request To Date";
            searchtextbox.TextMode = TextBoxMode.Date;
        }
    }
    #endregion

    protected void viewMore_Click(object sender, EventArgs e) {
        Response.Redirect("ClaimDetails.aspx");
    }
}